--Creazione DB ToysGroup---
CREATE DATABASE ToysGroup;
/*Descrivi la struttura delle tabelle che reputi utili e sufficienti a modellare lo scenario proposto tramite la sintassi DDL. 
Implementa fisicamente le tabelle utilizzando il DBMS SQL Server (o altro).*/
USE ToysGroup;
CREATE TABLE STATES
(
StateID INT NOT NULL,
StateIntCode char(2),
StateName nvarchar(50),
RegionID INT
CONSTRAINT PK_STATES PRIMARY KEY (StateID),
CONSTRAINT FK_STATES_REGIONS FOREIGN KEY (RegionID) REFERENCES REGIONS(RegionID)
);

CREATE TABLE REGIONS
(
RegionID INT NOT NULL,
RegionArea nvarchar(30),
RegionMacroArea nvarchar(30)
CONSTRAINT PK_REGIONS PRIMARY KEY (RegionID)
);

CREATE TABLE PRODUCT_CATEGORY
(
ProductCategoryID INT NOT NULL,
ProductCategoryName nvarchar(50)
CONSTRAINT PK_PRODUCT_CATEGORY PRIMARY KEY (ProductCategoryID)
);

CREATE TABLE PRODUCT
(
ProductKey INT NOT NULL,
ProductName nvarchar(50),
ProductCategoryID INT,
ListPrice decimal (10,2),
StandardCost decimal (10,2),
Size nvarchar(50),
Weight decimal(5,1),
Color nvarchar(50),
Description nvarchar(200)
CONSTRAINT PK_PRODUCTS PRIMARY KEY (ProductKey),
CONSTRAINT FK_PRODUCTS_PRODUCT_CATEGORY FOREIGN KEY (ProductCategoryID) REFERENCES PRODUCT_CATEGORY(ProductCategoryID)
);

CREATE TABLE SALES
(
OrderNumber INT NOT NULL,
OrderLine tinyint NOT NULL,
ProductKey INT,
Quantity INT,
UnitPrice decimal (10,2),
SalesAmount decimal (10,2),
OrderDate date,
SalesStateID INT
CONSTRAINT PK_SALES PRIMARY KEY (OrderNumber,OrderLine),
CONSTRAINT FK_SALES_PRODUCTS FOREIGN KEY (ProductKey) REFERENCES PRODUCT(ProductKey),
CONSTRAINT FK_SALES_STATES FOREIGN KEY (SalesStateID) REFERENCES STATES(StateID)
);

/*Popola le tabelle utilizzando dati a tua discrezione (sono sufficienti pochi record per tabella; riporta le query utilizzate) */
INSERT INTO REGIONS (RegionID, RegionArea, RegionMacroArea)
VALUES 
(1,'South Europe','Europe'),
(2,'North Europe','Europe'),
(3,'East Europe','Europe'),
(4,'West Europe','Europe'),
(5,'North America','America'),
(6,'Latin America','America'),
(7,'Middle East','Asia'),
(8,'South Asia','Asia'),
(9,'South East Asia','Asia'),
(10, 'Far East','Asia'),
(11,'North Africa','Africa'),
(12,'Central Africa','Africa'),
(13,'West Africa','Africa'),
(14,'Southern Africa','Africa'),
(15, 'Oceania', 'Oceania');

INSERT INTO STATES (StateID,StateIntCode,StateName,RegionID)
VALUES
(1,'IT','Italy',1),
(2,'ES','Spain',1),
(3,'GR','Greece',1),
(4,'NO','Norway',2),
(5,'SE','Sweden',2),
(6,'RU','Russia',3),
(7,'RO','Romania',3),
(8,'GB','United Kingdom',4),
(9,'DE','Germany',4),
(10,'FR','France',4),
(11,'NL','Netherlands',4),
(12,'US','United States of America',5),
(13,'CA','Canada',5),
(14,'MX','Mexico',5),
(15,'BR','Brazil',6),
(16,'AR','Argentina',6),
(17,'SA','Saudi Arabia',7),
(18,'AE','United Arab Emirates',7),
(19,'IL','Israel',7),
(20,'ID','Indonesia',9),
(21,'PH','Phillippines',9),
(22,'IN','India',8),
(23,'PK','Pakistan',8),
(24,'CN','China',10),
(25,'JP','Japan',10),
(26,'KR','South Korea',10),
(27,'EG','Egypt',11),
(28,'CM','Camerun',12),
(29,'GH','Ghana',13),
(30,'ZA','South Africa',14),
(31,'AU','Australia',15),
(32,'NZ','New Zealand',15);

INSERT INTO PRODUCT_CATEGORY (ProductCategoryID,ProductCategoryName)
VALUES
(1, 'Dolls'),
(2, 'Educational'),
(3, 'Blocks'),
(4, 'Vehicles'),
(5, 'Outdoor'),
(6, 'Board Games'),
(7, 'Consoles'),
(8, 'Plush Toys'),
(9, 'Artistic and Creative'),
(10, 'Role-Playing'),
(11, 'Robotics'),
(12, 'Collectable');

INSERT INTO PRODUCT (ProductKey, ProductName, ProductCategoryID, ListPrice, StandardCost, Size, Weight, Color, Description)
VALUES
(1,'Barbie Dreamhouse Playset',1,239.99,190.00,'28.35x69.69x42.91',23.8,'Pink','A comprehensive playset that includes a Barbie doll, furniture, and accessories for creating imaginative scenarios in a dollhouse setting'),
(2,'LeapFrog LeapStart Interactive Learning System',2,132.74,112.56,'4,75x24,51x28,7',1.48,'White','An educational system that engages children in reading, math, and other subjects through interactive books and activities'),
(3,'LEGO Creator Expert Taj Mahal',3,505.67,368.15,'58,5x19x49',7.13,'Black','A highly detailed LEGO set that allows kids and adults to build a miniature version of the iconic Taj Mahal'),
(4,'Hot Wheels Super Ultimate Garage Playset',4,196.23,163.99,'20,32x76,2x86,36',1.00,'Red','A large playset featuring a multi-level garage, race tracks, and various features for playing with Hot Wheels cars'),
(5,'Little Tikes Totsports Easy Hit Golf Set',5,33.90,28.50,'54,61x26,67x19,05',1.78,'Red','A child-friendly golf set designed for outdoor play, including colorful clubs, balls, and a mini-golf course'),
(6,'Settlers of Catan',6,39.90,31.25,'30x30x7',1.31,'Blue','A popular strategy board game where players collect resources to build roads, settlements, and cities on the fictional island of Catan'),
(7,'Nintendo Switch Lite',7,209.99,159.60,'19.5x35.3x9',1.11,'Grey','A handheld gaming console from Nintendo that provides a portable and compact gaming experience for kids'),
(8,'Disney Frozen Elsa Plush Doll',8,25.90,17.85,'10x11x20',0.27,'Blue','A soft and huggable plush doll featuring Elsa, the popular character from Disneys Frozen'),
(9,'Crayola Inspiration Art Case',9,28.95,21.30,'39.4x5.8x28',1.50,'Black','An art set containing a variety of Crayola crayons, colored pencils, markers, and drawing paper for creative expression'),
(10,'Melissa & Doug Fire Chief Role Play Costume Set',10,74.58,65.00,'44x61.5x5',0.77,'Red','A firefighter costume set for kids, including a jacket, helmet, badge, fire extinguisher, and other accessories for imaginative play'),
(11,'LEGO Mindstorms EV3 Robot Kit',11,399.99,286.75,'11x7.5x4.5',0.18,'Grey','A robotics kit that allows users to build and program their own customizable robots using LEGO components'),
(12,'Funko Pop! Marvel Avengers Endgame - Iron Man',12,26.30,21.35,'5x3.81x10.16',0.32,'Red','A collectible vinyl figure from the Funko Pop! series featuring Iron Man in a stylized and iconic design');

INSERT INTO SALES (OrderNumber,OrderLine,ProductKey,Quantity,UnitPrice,SalesAmount,OrderDate,SalesStateID)
VALUES
(00001,1,7,1,209.99,209.99,'2023-12-28',24),
(00001,2,2,1,132.74,132.74,'2023-12-28',24),
(00001,3,4,1,196.23,196.23,'2023-12-28',24),
(00002,1,8,1,25.90,25.90,'2024-01-05',1),
(00002,2,9,2,28.95,57.90,'2024-01-05',1),
(00003,1,3,1,505.67,505.67,'2024-01-06',13),
(00004,1,12,2,26.30,52.60,'2024-01-08',19),
(00004,2,10,1,74.58,74.58,'2024-01-08',19),
(00005,1,1,2,239.99,479.98,'2024-01-12',23),
(00006,1,11,1,399.99,399.99,'2024-01-1',2),
(00006,2,5,1,33.90,33.90,'2024-01-15',2),
(00006,3,6,1,39.90,39.90,'2024-01-15',2),
(00007,1,1,1,239.99,239.99,'2024-01-21',9),
(00007,2,7,1,209.99,209.99,'2024-01-21',9),
(00007,3,4,1,196.23,196.23,'2024-01-21',9),
(00007,4,3,1,505.67,505.67,'2024-01-21',9),
(00008,1,5,1,33.90,33.90,'2024-01-25',20),
(00009,1,12,2,26.30,52.60,'2024-01-28',28),
(00009,2,8,1,25.90,25.90,'2024-01-28',28),
(00010,1,2,1,132.74,132.74,'2024-01-28',31),
(00010,2,4,1,196.23,196.23,'2024-01-28',31),
(00010,3,7,1,209.99,209.99,'2024-01-28',31);

/*1)Verificare che i campi definiti come PK siano univoci. 
In altre parole, scrivi una query per determinare l�univocit� dei valori di ciascuna PK (una query per tabella implementata).*/

SELECT ProductKey FROM PRODUCT GROUP BY ProductKey HAVING COUNT(*)>1;
SELECT ProductCategoryID FROM PRODUCT_CATEGORY GROUP BY ProductCategoryID HAVING COUNT(*)>1;
SELECT RegionID FROM REGIONS GROUP BY RegionID HAVING COUNT(*)>1;
SELECT OrderNumber,OrderLine FROM SALES GROUP BY OrderNumber,OrderLine HAVING COUNT(*)>1;
SELECT StateID FROM STATES GROUP BY StateID HAVING COUNT(*)>1;

/*2)Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto, la categoria del prodotto, 
il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato in base alla condizione che siano passati pi� di 180 giorni 
dalla data vendita o meno (>180 -> True, <= 180 -> False)*/

SELECT S.OrderNumber,S.OrderLine,S.OrderDate,P.ProductName,C.ProductCategoryName,ST.StateName,R.RegionArea,
CASE WHEN DATEDIFF(d,s.orderdate,GETDATE())>180 THEN 'Yes' ELSE 'No' END AS 'Sold Before This Semester'
FROM SALES AS S
JOIN PRODUCT AS P ON S.ProductKey = P.ProductKey
JOIN PRODUCT_CATEGORY AS C ON P.ProductCategoryID = C.ProductCategoryID
JOIN STATES AS ST ON S.SalesStateID = ST.StateID
JOIN REGIONS AS R ON ST.RegionID = R.RegionID

/*3)Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno*/

SELECT P.ProductKey, P.ProductName, SUM(S.SalesAmount) AS TotalSales, YEAR(S.OrderDate) AS SalesYear
FROM SALES AS S
JOIN PRODUCT AS P
ON S.ProductKey = P.ProductKey
GROUP BY P.ProductKey, P.ProductName, YEAR(S.OrderDate)
ORDER BY P.ProductKey, SalesYear

/*4)Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.*/

SELECT SalesStateID, StateName, SUM(SalesAmount) AS TotalSales, YEAR(OrderDate) AS SalesYear
FROM SALES as S
JOIN STATES as ST
ON S.SalesStateID = ST.StateID
GROUP BY SalesStateID, StateName, YEAR(OrderDate)
ORDER BY SalesYear, TotalSales DESC

/*5)Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT TOP 1 ProductCategoryName, MAX(TotalRequests) AS MaxRequest
FROM
    (	SELECT P.ProductCategoryID, COUNT(*) AS TotalRequests
		FROM SALES AS S
		JOIN PRODUCT AS P 
		ON	S.ProductKey = P.ProductKey
		GROUP BY P.ProductCategoryID
	) AS TR
JOIN PRODUCT_CATEGORY AS C 
ON TR.ProductCategoryID = C.ProductCategoryID
GROUP BY ProductCategoryName
ORDER BY MaxRequest DESC

/*6)Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.*/

SELECT ProductKey, ProductName
FROM PRODUCT
WHERE ProductKey NOT IN ( SELECT ProductKey 
							FROM SALES )

SELECT P.ProductKey, ProductName
FROM PRODUCT AS P
LEFT JOIN SALES AS S
ON P.ProductKey = S.ProductKey
WHERE S.ProductKey IS NULL
							

/*7)Esporre l�elenco dei prodotti cona la rispettiva ultima data di vendita (la data di vendita pi� recente).*/

SELECT P.ProductName,S1.OrderDate, S1.OrderNumber
FROM SALES AS S1
JOIN PRODUCT AS P
ON S1.ProductKey = P.ProductKey
WHERE S1.OrderDate = (SELECT MAX(S2.OrderDate)
						FROM SALES AS S2
						WHERE S1.ProductKey = S2.ProductKey
						)
ORDER BY S1.ProductKey


/*8)Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni utili (codice prodotto, nome prodotto, nome categoria)*/

CREATE VIEW VW_SP_Products AS
SELECT ProductKey,ProductName,ProductCategoryName
FROM PRODUCT AS P
JOIN PRODUCT_CATEGORY AS C
ON P.ProductCategoryID = C.ProductCategoryID

/*9)Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche*/

CREATE VIEW VW_SP_States AS
SELECT StateID,StateName,RegionArea,RegionMacroArea
FROM STATES AS S
JOIN REGIONS AS R
ON S.RegionID = R.RegionID

/*10)Esercizio opzionale: ottenute le viste per la costruzione delle dimensioni di analisi prodotto (punto 7)  
	e area geografica (punto 8), implementa un modello logico in Power Query e costruisci un report per l�analisi delle vendite*/

---VEDI FILE XLSX IN ALLEGATO ALLA CARTELLA ----


